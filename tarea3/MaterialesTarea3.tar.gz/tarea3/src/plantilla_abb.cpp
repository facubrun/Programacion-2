/* abcdefg */ // sustituiir con los 7 dígitos de la cédula

#include "../include/abb.h"

struct _rep_abb {};

TAbb crearAbb() { return NULL; }

void liberarAbb(TAbb abb) {}

bool esVacioAbb(TAbb abb) { return false; }

TAbb buscarSubarbol(nat clave, TAbb abb) { return NULL; }

TInfo raiz(TAbb abb) { return NULL; }

TAbb izquierdo(TAbb abb) { return NULL; }

TAbb derecho(TAbb abb) { return NULL; }

TInfo menorEnAbb(TAbb abb) { return NULL; }

TInfo mayorEnAbb(TAbb abb) { return NULL; }

TAbb consAbb(TInfo dato, TAbb izq, TAbb der) { return NULL; }

TAbb insertarEnAbb(TInfo dato, TAbb abb) { return NULL; }

TAbb removerDeAbb(nat clave, TAbb abb) { return NULL; }

TAbb copiaAbb(TAbb abb) { return NULL; }
