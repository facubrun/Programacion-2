/* abcdefg */ // sustituiir con los 7 dígitos de la cédula

#include "../include/aplicaciones.h"

TCadena linealizacion(TAbb abb) { return NULL; }

void imprimirAbb(TAbb abb) {}

bool esPerfecto(TAbb abb) { return false; }

TAbb menores(double limite, TAbb abb) { return NULL; }

TIterador caminoAscendente(nat clave, nat k, TAbb abb) { return NULL; }

void imprimirPalabrasCortas(nat k, TPalabras palabras) {}

TPalabras buscarFinPrefijo(ArregloChars prefijo, TPalabras palabras) {
  return NULL;
}
